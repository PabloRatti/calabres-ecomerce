var transactionTest = require('./transactionTest');
var discoverTest = require('./discoverTest');
var pushNotificationTest = require('./pushNotificationTest');
var getCredentialsTest = require('./getCredentialsTest');
